package Command;

import java.awt.Color;

public class Main {

	public static void main(String[] args) {
		
		DrawCom draw = new DrawCom();
		
//		Circle circle =new Circle();
//		

		/*
		circleSizer.getSize(32);
		selection.press();
		
		selection.pressUndo();
		
		circleSizer.getSize(52);
		selection.press();
		
		selection.pressUndo();
		
		/*
		
		CircleReColor circleColor = new CircleReColor(circle);
		circleColor.getColor(Color.black);
		
		selection =new Selection(circleColor);
		selection.press();
		
		circleColor.getColor(Color.BLUE);
		selection.press();
		
		selection.pressUndo();
		
		circleColor.getColor(Color.DARK_GRAY);
		selection.press();
		
		selection.pressUndo();
		
		CircleReposition circleReposition = new CircleReposition(circle);
		circleReposition.getPosition(10000,20000);
		
		selection =new Selection(circleReposition);
		selection.press();
		
		circleReposition.getPosition(30000,40000);
		selection.press();
		
		selection.pressUndo();
		
		circleReposition.getPosition(50000,60000);
		selection.press();
		
		selection.pressUndo();
		*/
		

	}

}
