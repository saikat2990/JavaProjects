package CompositePattern;

public class CompositeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//OrientalMainDraw d = new OrientalMainDraw();
		Envirment envirment = new OrientalEnvirnment();
		//Envirment envirment = new OccidentalEnvirnment();
		//OccidentalMainDraw occidentalMainDraw = new OccidentalMainDraw();
		//Rectangle flag = new Rectangle(d,100,200,100,200);
		//flag.draw();
	}

}
