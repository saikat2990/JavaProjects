package CompositePattern;

public interface Pond {
	public int getWater();

	public void draw();
}
