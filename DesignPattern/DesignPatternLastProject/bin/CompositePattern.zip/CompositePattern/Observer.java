package CompositePattern;

public interface Observer {
	
	public void Update(String data);
	
}
