package CompositePattern;

public interface HutBuilder {
	
	
	public void draw();
	
}
