package CompositePattern;

import java.awt.Graphics;

public interface Flora {
	
	public void buildFlora(Graphics g);
	
}
