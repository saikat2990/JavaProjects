package CompositePattern;

public interface Founa {
	public void selectFouna();
	public void draw();
}
