package CompositePattern;

public class OrientalIsland implements IslandInterface{

	@Override
	public void selectEnvirment() {
		// TODO Auto-generated method stub
		
	}

}
