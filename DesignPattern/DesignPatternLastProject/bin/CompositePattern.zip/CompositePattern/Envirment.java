package CompositePattern;

public interface Envirment {
	
	public void selectFlora();
	public void selectFouna();
	public void selectHutBuilder();

}
