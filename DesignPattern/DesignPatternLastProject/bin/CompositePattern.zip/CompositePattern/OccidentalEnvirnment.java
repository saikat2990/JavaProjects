package CompositePattern;

public class OccidentalEnvirnment implements Envirment {
	
	public OccidentalEnvirnment() {
		// TODO Auto-generated constructor stub
		OccidentalMainDraw occidentalMainDraw = new OccidentalMainDraw();
	}
	@Override
	public void selectFlora() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectFouna() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectHutBuilder() {
		// TODO Auto-generated method stub
		
	}
}
