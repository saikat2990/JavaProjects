package CompositePattern;

public class OrientalEnvirnment implements Envirment {


	public OrientalEnvirnment(){
		
		OrientalMainDraw orientalMainDraw = new OrientalMainDraw();
	}
	public void selectFlora() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectFouna() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void selectHutBuilder() {
		// TODO Auto-generated method stub
		
	}

}
