package CompositePattern;

public class OrientalObserver implements Observer{

	@Override
	public void Update(String data) {
		// TODO Auto-generated method stub
		System.out.println(data);
		
	}

}
