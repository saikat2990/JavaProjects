package CompositePattern;

public interface IslandInterface {
	public void selectEnvirment();
}
