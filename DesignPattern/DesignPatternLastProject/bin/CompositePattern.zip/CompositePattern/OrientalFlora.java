package CompositePattern;

import java.awt.Graphics;

public class OrientalFlora implements Flora{

	@Override
	public void buildFlora(Graphics g) {
		// TODO Auto-generated method stub
		
	}

}
