package CompositePattern;

public class OccidentalIsland implements IslandInterface{

	@Override
	public void selectEnvirment() {
		// TODO Auto-generated method stub
		
	}
}
