package BuilderPattern;

public abstract class Desert implements Menu{
	public abstract double getCost();
}
