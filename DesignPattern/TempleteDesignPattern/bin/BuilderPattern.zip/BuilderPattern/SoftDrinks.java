package BuilderPattern;

public abstract class SoftDrinks implements  Menu{
	
	public abstract double getCost();
}
