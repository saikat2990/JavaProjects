package BuilderPattern;

public class Pepsi implements Menu {

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0.6;
	}

}
