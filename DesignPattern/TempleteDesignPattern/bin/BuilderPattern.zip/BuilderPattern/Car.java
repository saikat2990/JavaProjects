package BuilderPattern;

public class Car extends Gift {

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0.7;
	}

}
