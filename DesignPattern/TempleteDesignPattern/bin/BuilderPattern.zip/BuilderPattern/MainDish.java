package BuilderPattern;

public abstract class MainDish implements Menu{
	public abstract double getCost();
}
