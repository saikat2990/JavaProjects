package BuilderPattern;

public class chessCake extends Desert{

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0.123;
	}

}
