package BuilderPattern;

public interface Menu {

	double getCost();
	
	
}
