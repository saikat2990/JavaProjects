package BuilderPattern;

public abstract class Gift implements Menu {
	public abstract double getCost();
}
