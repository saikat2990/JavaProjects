package BuilderPattern;

public class Burger extends MainDish{

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0.231;
	}

}
