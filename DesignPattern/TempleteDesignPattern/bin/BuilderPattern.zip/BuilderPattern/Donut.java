package BuilderPattern;

public class Donut extends Desert{

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0.345;
	}

}
