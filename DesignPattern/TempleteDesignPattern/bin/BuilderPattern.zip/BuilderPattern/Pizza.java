package BuilderPattern;

public class Pizza extends MainDish{

	@Override
	public double getCost() {
		
		return 1.2;
	}
	
}
