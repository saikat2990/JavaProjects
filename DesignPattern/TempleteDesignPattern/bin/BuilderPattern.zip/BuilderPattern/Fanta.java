package BuilderPattern;

public class Fanta extends SoftDrinks{

	@Override
	public double getCost() {
		// TODO Auto-generated method stub
		return 0.34;
	}

}
