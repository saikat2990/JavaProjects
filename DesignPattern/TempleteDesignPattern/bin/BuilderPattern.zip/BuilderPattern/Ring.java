package BuilderPattern;

public class Ring extends Gift{

	@Override
	public double getCost() {
		
		return 0.5;
	}

}
